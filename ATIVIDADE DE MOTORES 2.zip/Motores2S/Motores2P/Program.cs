﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Motores2P
{
    
    internal class Program
    {
        static double[] valor;
        static void lancar()
        {
            int motor;
            do
            {
                Console.Write("Qual o motor ?");
                motor = int.Parse(Console.ReadLine());
            }
            while (motor < 1 || motor > 15);

            Console.Write("Qual o valor ?");
            valor[motor - 1] += double.Parse(Console.ReadLine());

            Console.WriteLine("Valor registrado!");

        }
        static void mostrar()
        {
            int motor;
            double total;

            total = 0;
            for (motor = 0; motor < 15; motor++)
            {
                Console.WriteLine("Motor {0}: R$ {1}",
                    motor + 1, valor[motor]);
                total += valor[motor];
            }
            Console.WriteLine("-------");
            Console.WriteLine("Total: R$ {0}", total);

        }
        static void maior()
        {
            double maior;
            int i;
            int cont;

            maior = 0;
            cont = 0;
            if (valor.Sum() == 0)
            {
                Console.WriteLine("Digite algum valor usuario");
            }
            else
            {
                for (i = 0; i < 15; i++)
                {

                    if (valor[i] > maior)
                    {
                        maior = valor[i];
                        cont = i;

                    }

                }
                Console.WriteLine("Maior valor: {0} - motor {1}", maior, cont + 1);
            }
        }
        static void menor()
        {
            double menor;
            int i;
            int cont;

            menor = 9999999999999999999;
            cont = 0;

            if (valor.Sum() == 0)
            {
                Console.WriteLine("Digite algum valor usuario");
            }
            else
            {
                for (i = 0; i < 15; i++)
                {
                    if (valor[i] != 0) 
                    if (valor[i] < menor)
                    {
                        menor = valor[i];
                        cont = i;

                    }
                }


                Console.WriteLine("Menor valor: {0} - motor {1}", menor, cont + 1);
            }
        }
        static void Main(string[] args)
        {

            valor = new double[15];
            int op;


            do
            {
                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Lançar valor");
                Console.WriteLine("2. Mostrar valores");
                Console.WriteLine("3. Maior valor");
                Console.WriteLine("4. Menor valor");
                Console.Write("Sua opção: ");
                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        {
                            lancar();
                            break;
                        }
                    case 2:
                        {
                            mostrar();
                            break;
                        }
                    case 3:
                        {
                            maior();
                            break;
                        }
                    case 4:
                        {
                            menor();
                            break;
                        }
                }
            }
            while (op != 0);

        }
    }
}
